package br.newtonpaiva.dominio;

import java.util.ArrayList;
import java.util.List;

public class Ingredientes {
    private String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
